import serial

def gps_get():
  #创建gps串口的句柄
  ser = serial.Serial("/dev/ttyUSB0", 9600 )  
 
  print("获取句柄成功，进入循环：")
  c = 0
  while True:
    line = str(str(ser.readline())[2:]) 
    if line.startswith('$GNGGA'):
      print('接收的数据：' + str(line))
      line = str(line).split(',')
      bjts=float(line[1][:2])+float(8)
      bjtf=line[1][2:4]
      bjtm=line[1][4:6]
      jing = float(line[4][:3])+ float(line[4][3:5])/60
      wei = float(line[2][:2]) + float(line[2][2:4])/60
      hb=float(line[9])
      zt=float(line[6])
      weixing=float(line[7])
      hdop=float(line[8])
      yichang=float(line[11])
      print("GPS状态指示",zt,"---(0-定位模式不可用或无效；1-GPS SPS模式，定位有效)")
      print("北京时间:",bjts,"时",bjtf,"分",bjtm,"秒")
      print("经度:",jing,line[5])
      print("纬度:",wei,line[3])
      print("海拔",hb,"米")
      print("参与定位的卫星数：",weixing)
      print("高程异常",yichang,"米")
      print("HDOP值",hdop)
      c=c+1
      if(c==5):
        break
