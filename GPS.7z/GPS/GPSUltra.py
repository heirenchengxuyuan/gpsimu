from GPSPROMAX import  gps_get

while True:
     gps_get()
     time.sleep(2)

